import sys
sys.path.append("/home/abc/PycharmProjects/fintech_crawler/")
