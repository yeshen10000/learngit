# set hdfs env
HDFS_HOST = ["abc-cloudera004", "abc-cloudera002"]
HDFS_PORT = "50070"

# set redis env
REDIS_HOST = "10.174.97.43"
REDIS_PORT = "6379"

# set hbase env
HBASE_HOST = "abc-cloudera006"
HBASE_PORT = "9090"
